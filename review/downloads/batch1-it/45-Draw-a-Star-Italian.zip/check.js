// Platform Gate 3: verify the stress HUD during a held press and cooldown.
module.exports = async function(page, ctx = {}) {
  const fs = require('fs'), path = require('path');
  const out = path.resolve(ctx.workDir || process.cwd(), '.preview');
  fs.mkdirSync(out, {recursive:true});
  const errors = [], onError = error => errors.push(String(error));
  page.on('pageerror', onError);
  try {
    await page.waitForSelector('.stress-value', {timeout:4000});
    await page.screenshot({path:path.join(out,'initial.png')});
    const size = await page.evaluate(() => ({w:innerWidth,h:innerHeight}));
    await page.mouse.move(size.w*.5, size.h*.55);
    await page.mouse.down();
    await page.waitForFunction(() => parseInt(document.querySelector('.stress-value')?.textContent,10) >= 12, null, {timeout:1500});
    const held = await page.locator('.stress-value').evaluate(el => parseInt(el.textContent,10));
    await page.screenshot({path:path.join(out,'gameplay.png')});
    await page.mouse.up();
    await page.waitForFunction(value => parseInt(document.querySelector('.stress-value')?.textContent,10) < value - 3, held, {timeout:1000});
    if (errors.length) throw Error(errors.join('\n'));
    return {ok:true,liveStress:true,cooldown:true,screenshots:['.preview/initial.png','.preview/gameplay.png']};
  } finally {
    await page.mouse.up();
    page.off('pageerror', onError);
  }
};
